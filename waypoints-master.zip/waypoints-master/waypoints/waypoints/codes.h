#pragma once
#pragma once
#ifndef CODES_H
#define CODES_H 1

#define TK_CODE_QUITTING 801
#define TK_CODE_MISC 802 
#define TK_CODE_SAVE 803
#define TK_CODE_GENERATE 805
#define TK_CODE_LEFTCLICK 806
#define TK_CODE_RIGHTCLICK 807
#define TK_CODE_NAVIGATE 844
#define TK_CODE_FILL 888
#endif