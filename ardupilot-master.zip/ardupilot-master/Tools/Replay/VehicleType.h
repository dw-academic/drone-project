#pragma once

class VehicleType {
public:
    enum vehicle_type {
        VEHICLE_UNKNOWN,
        VEHICLE_COPTER,
        VEHICLE_PLANE,
        VEHICLE_ROVER
    };
};
