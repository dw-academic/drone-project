BBBmini Device Tree files are part of the [dtb-rebuilder](https://github.com/RobertCNelson/dtb-rebuilder) repository and included in the BeagleBone Debian images.
