#ifndef TK_CONSTS_H
#define TK_CONSTS_H 1


// write universal definetions here
#define TK_DATA_FILE_PATH "/ardu.data"
#define TRIM_ZONE 10
#define TRIM_SCALE 1
#endif
